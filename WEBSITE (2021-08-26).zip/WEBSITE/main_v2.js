var x = document.getElementById("demo");
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}
function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude + 
  "<br>Longitude: " + position.coords.longitude;
}

var vm = new Vue({
  el: '#user_name_testing',
  data: {
    firstName: 'Tony',
    lastName: 'Chan'
  },
  computed: {
    fullName: function () {
      return this.firstName + ' ' + this.lastName
    }
  }
})

new Vue({
  el: '#content_publish_information',
  data: {
    object: {
      title: 'Tips on how to manage your time',
      author: 'Tom Banner',
      published_date: '2021-08-13',
    }
  }
})

new Vue({
  el: '...',
  data: {
    checkedNames: []
  }
})

new Vue({
  el: '...',
  data: {
    selected: ''
  }
})